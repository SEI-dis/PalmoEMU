#ifndef FM_H
#define FM_H

#include <stddef.h>

#include "../libraries/clowncommon/clowncommon.h"

#include "fm-channel.h"
#include "fm-lfo.h"

/* 8 is chosen because there are 6 FM channels (of which the DAC can replace one).
   Dividing by 8 is simpler than dividing by 6, so that was opted for instead. */
#define FM_VOLUME_DIVISOR 8

#define FM_PRESCALER 6
#define FM_TOTAL_CHANNELS 6

#define FM_SAMPLE_RATE_DIVIDER (FM_PRESCALER * FM_TOTAL_CHANNELS * FM_TOTAL_OPERATORS)

#define FM_PARAMETERS_INITIALISE(CONFIGURATION, STATE) { \
		(CONFIGURATION), \
		(STATE), \
	}

typedef struct FM_ChannelMetadata
{
	FM_Channel state;
	cc_bool pan_left;
	cc_bool pan_right;
} FM_ChannelMetadata;

typedef struct FM_Configuration
{
	cc_bool fm_channels_disabled[FM_TOTAL_CHANNELS];
	cc_bool dac_channel_disabled;
	cc_bool ladder_effect_disabled;
} FM_Configuration;

typedef struct FM_Timer
{
	cc_u32l value;
	cc_u32l counter;
	cc_bool enabled;
} FM_Timer;

typedef struct FM_State
{
	FM_ChannelMetadata channels[FM_TOTAL_CHANNELS];
	struct
	{
		cc_u16l frequencies[FM_TOTAL_OPERATORS];
		cc_bool per_operator_frequencies_enabled;
		cc_bool csm_mode_enabled;
	} channel_3_metadata;
	cc_u8l port;
	cc_u8l address;
	cc_u16l dac_sample;
	cc_bool dac_enabled, dac_test;
	cc_u16l raw_timer_a_value;
	FM_Timer timers[2];
	cc_u8l cached_address_27;
	cc_u8l cached_upper_frequency_bits, cached_upper_frequency_bits_fm3_multi_frequency;
	cc_u8l leftover_cycles;
	cc_u8l status;
	cc_u8l busy_flag_counter;
	FM_LFO lfo;
} FM_State;

typedef struct FM
{
	FM_Configuration configuration;
	FM_State state;
} FM;

void FM_Initialise(FM *fm);

void FM_DoAddress(FM *fm, cc_u8f port, cc_u8f address);
void FM_DoData(FM *fm, cc_u8f data);

void FM_OutputSamples(FM *fm, cc_s16l *sample_buffer, cc_u32f total_frames);
/* Updates the FM's internal state and outputs samples. */
/* The samples are stereo and in signed 16-bit PCM format. */
cc_u8f FM_Update( FM *fm, cc_u32f cycles_to_do, void (*fm_audio_to_be_generated)(const void *user_data, cc_u32f total_frames), const void *user_data);

#endif /* FM_H */
