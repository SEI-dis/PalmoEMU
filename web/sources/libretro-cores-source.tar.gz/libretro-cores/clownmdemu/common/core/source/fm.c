/*
TODO:

CSM Mode:
http://gendev.spritesmind.net/forum/viewtopic.php?p=5650#p5650

Differences between YM2612 and YM2608:
http://gendev.spritesmind.net/forum/viewtopic.php?p=5680#p5680

Timing of timer counter updates:
http://gendev.spritesmind.net/forum/viewtopic.php?p=5687#p5687

Test register that makes every channel output the DAC sample:
http://gendev.spritesmind.net/forum/viewtopic.php?t=1118

How the envelope generator works:
http://gendev.spritesmind.net/forum/viewtopic.php?p=5716#p5716
http://gendev.spritesmind.net/forum/viewtopic.php?p=6224#p6224
http://gendev.spritesmind.net/forum/viewtopic.php?p=6522#p6522

Sine table resolution, DAC and FM operator mixing/volume/clipping:
http://gendev.spritesmind.net/forum/viewtopic.php?p=5958#p5958

Maybe I should implement multiplexing instead of mixing the 6 channel together?
Multiplexing is more authentic, but is mixing *better*?

FM and PSG balancing:
http://gendev.spritesmind.net/forum/viewtopic.php?p=5960#p5960:

Operator output caching during algorithm stage:
http://gendev.spritesmind.net/forum/viewtopic.php?p=6090#p6090

Self-feedback patents:
http://gendev.spritesmind.net/forum/viewtopic.php?p=6096#p6096

How the operator unit works:
http://gendev.spritesmind.net/forum/viewtopic.php?p=6114#p6114

How the phase generator works:
http://gendev.spritesmind.net/forum/viewtopic.php?p=6177#p6177

Some details about the DAC:
http://gendev.spritesmind.net/forum/viewtopic.php?p=6258#p6258

Operator unit value recycling:
http://gendev.spritesmind.net/forum/viewtopic.php?p=6287#p6287
http://gendev.spritesmind.net/forum/viewtopic.php?p=6333#p6333

Some details on the internal tables:
http://gendev.spritesmind.net/forum/viewtopic.php?p=6741#p6741

LFO locking bug:
http://gendev.spritesmind.net/forum/viewtopic.php?p=7490#p7490

Multiplexing details:
http://gendev.spritesmind.net/forum/viewtopic.php?p=7509#p7509

Multiplexing ordering:
http://gendev.spritesmind.net/forum/viewtopic.php?p=7516#p7516

Corrected and expanded envelope generator stuff:
http://gendev.spritesmind.net/forum/viewtopic.php?p=7967#p7967

Some miscellaneous details (there's a bunch of minor stuff after it too):
http://gendev.spritesmind.net/forum/viewtopic.php?p=7999#p7999

YM3438 differences:
http://gendev.spritesmind.net/forum/viewtopic.php?p=8406#p8406

Phase generator steps:
http://gendev.spritesmind.net/forum/viewtopic.php?p=8908#p8908

Simulating the multiplex with addition:
http://gendev.spritesmind.net/forum/viewtopic.php?p=10441#p10441

DAC precision loss:
http://gendev.spritesmind.net/forum/viewtopic.php?p=11873#p11873

DAC and FM6 updating:
http://gendev.spritesmind.net/forum/viewtopic.php?p=14105#p14105

Some questions:
http://gendev.spritesmind.net/forum/viewtopic.php?p=18723#p18723

Debug register and die shot analysis:
http://gendev.spritesmind.net/forum/viewtopic.php?p=26964#p26964

The dumb busy flag:
http://gendev.spritesmind.net/forum/viewtopic.php?p=27124#p27124

Control unit (check stuff afterwards too):
http://gendev.spritesmind.net/forum/viewtopic.php?p=29471#p29471

More info about one of the test registers:
http://gendev.spritesmind.net/forum/viewtopic.php?p=30065#p30065

LFO queries:
http://gendev.spritesmind.net/forum/viewtopic.php?p=30935#p30935

More test register stuff:
http://gendev.spritesmind.net/forum/viewtopic.php?p=31285#p31285

And of course there's Nuked, which will answer all questions once and for all:
https://github.com/nukeykt/Nuked-OPN2

The 9th DAC sample bit.

*/

#include "fm.h"

#include <math.h>

#include "../libraries/clowncommon/clowncommon.h"

#include "log.h"

static cc_u16f FM_ConvertTimerAValue(const cc_u16f value)
{
	return 0x400 - value;
}

static cc_u16f FM_ConvertTimerBValue(const cc_u16f value)
{
	return 0x10 * (0x100 - value);
}

void FM_Initialise(FM* const fm)
{
	FM_ChannelMetadata *channel;
	cc_u8f i;

	for (channel = &fm->state.channels[0]; channel < &fm->state.channels[CC_COUNT_OF(fm->state.channels)]; ++channel)
	{
		FM_Channel_Initialise(&channel->state);

		/* Panning must be enabled by default. Without this, Sonic 1's 'Sega' chant doesn't play. */
		channel->pan_left = cc_true;
		channel->pan_right = cc_true;
	}

	for (i = 0; i < CC_COUNT_OF(fm->state.channel_3_metadata.frequencies); ++i)
		fm->state.channel_3_metadata.frequencies[i] = 0;

	fm->state.channel_3_metadata.per_operator_frequencies_enabled = cc_false;
	fm->state.channel_3_metadata.csm_mode_enabled = cc_false;

	fm->state.port = 0 * 3;
	fm->state.address = 0;

	fm->state.dac_sample = 0x100; /* Silence */
	fm->state.dac_enabled = cc_false;
	fm->state.dac_test = cc_false;

	fm->state.raw_timer_a_value = 0;

	fm->state.timers[0].value = FM_ConvertTimerAValue(0);
	fm->state.timers[0].counter = FM_ConvertTimerAValue(0);
	fm->state.timers[0].enabled = cc_false;

	fm->state.timers[1].value = FM_ConvertTimerBValue(0);
	fm->state.timers[1].counter = FM_ConvertTimerBValue(0);
	fm->state.timers[1].enabled = cc_false;

	fm->state.cached_address_27 = 0;
	fm->state.cached_upper_frequency_bits = fm->state.cached_upper_frequency_bits_fm3_multi_frequency = 0;
	fm->state.leftover_cycles = 0;
	fm->state.status = 0;
	fm->state.busy_flag_counter = 0;

	FM_LFO_Initialise(&fm->state.lfo);
}

void FM_DoAddress(FM* const fm, const cc_u8f port, const cc_u8f address)
{
	fm->state.port = port * 3;
	fm->state.address = address;
}

void FM_DoData(FM* const fm, const cc_u8f data)
{
	FM_State* const state = &fm->state;

	/* Set BUSY flag. */
	state->status |= 0x80;
	/* The YM2612's BUSY flag is always active for exactly 32 internal cycles. */
	state->busy_flag_counter = 32 * FM_PRESCALER;

	if (state->address < 0x30)
	{
		if (state->port == 0)
		{
			switch (state->address)
			{
				default:
					LogMessage("Unrecognised FM address latched (0x%02" CC_PRIXLEAST8 ")", state->address);
					break;

				case 0x22:
					if (FM_LFO_SetEnabled(&state->lfo, (data & 8) != 0))
					{
						FM_ChannelMetadata *channel;

						for (channel = &state->channels[0]; channel < &state->channels[CC_COUNT_OF(state->channels)]; ++channel)
							FM_Channel_SetPhaseModulation(&channel->state, state->lfo.phase_modulation);
					}

					state->lfo.frequency = data & 7;
					break;

				case 0x24:
					/* Oddly, the YM2608 manual describes these timers being twice as fast as they are here. */
					state->raw_timer_a_value &= 3;
					state->raw_timer_a_value |= data << 2;
					state->timers[0].value = FM_ConvertTimerAValue(state->raw_timer_a_value);
					break;

				case 0x25:
					state->raw_timer_a_value &= ~3;
					state->raw_timer_a_value |= data & 3;
					state->timers[0].value = FM_ConvertTimerAValue(state->raw_timer_a_value);
					break;

				case 0x26:
					state->timers[1].value = FM_ConvertTimerBValue(data);
					break;

				case 0x27:
				{
					const cc_bool fm3_per_operator_frequencies_enabled = (data & 0xC0) != 0;

					cc_u8f i;

					for (i = 0; i < CC_COUNT_OF(state->timers); ++i)
					{
						/* Only reload the timer on a rising edge. */
						if ((data & (1 << (0 + i))) != 0 && (state->cached_address_27 & (1 << (0 + i))) == 0)
							state->timers[i].counter = state->timers[i].value;

						/* Enable the timer. */
						state->timers[i].enabled = (data & (1 << (2 + i))) != 0;

						/* Clear the 'timer expired' flag. */
						if ((data & (1 << (4 + i))) != 0)
							state->status &= ~(1 << i);
					}

					/* Cache the contents of this write for the above rising-edge detection. */
					state->cached_address_27 = data;

					if (state->channel_3_metadata.per_operator_frequencies_enabled != fm3_per_operator_frequencies_enabled)
					{
						cc_u8f i;

						state->channel_3_metadata.per_operator_frequencies_enabled = fm3_per_operator_frequencies_enabled;

						for (i = 0; i < CC_COUNT_OF(state->channels[2].state.operators); ++i)
							FM_Channel_SetFrequency(&state->channels[2].state, i, state->lfo.phase_modulation, state->channel_3_metadata.frequencies[fm3_per_operator_frequencies_enabled ? i : 3]);
					}

					state->channel_3_metadata.csm_mode_enabled = (data & 0xC0) == 0x80;

					break;
				}

				case 0x28:
				{
					/* Key on/off. */
					/* There's a gap between channels 3 and 4. */
					/* TODO: Check what happens if you try to access the 'gap' channels on real hardware. */
					static const cc_u8f table[8] = {0, 1, 2, 0xFF, 3, 4, 5, 0xFF};
					const cc_u8f channel_index = table[data % CC_COUNT_OF(table)];

					if (channel_index != 0xFF)
					{
						FM_Channel* const channel = &state->channels[channel_index].state;

						cc_u8f i;

						for (i = 0; i < CC_COUNT_OF(channel->operators); ++i)
							FM_Channel_SetKeyOn(channel, i, (data & (1 << (4 + i))) != 0);
					}

					break;
				}

				case 0x2A:
					/* DAC sample. */
					state->dac_sample &= 1u;
					state->dac_sample |= (cc_u16f)data << 1;
					break;

				case 0x2B:
					/* DAC enable/disable. */
					state->dac_enabled = (data & 0x80) != 0;
					break;

				case 0x2C:
					/* LSI test 2 */
					state->dac_sample &= ~1u;
					state->dac_sample |= (data >> 3) & 1;
					state->dac_test = (data & (1 << 5)) != 0;
					break;
			}
		}
	}
	else
	{
		const cc_u16f slot_index = state->address & 3;
		const cc_u16f channel_index = state->port + slot_index;
		FM_ChannelMetadata* const channel_metadata = &state->channels[channel_index];
		FM_Channel* const channel = &state->channels[channel_index].state;

		/* There is no fourth channel per slot. */
		/* TODO: See how real hardware handles this. */
		if (slot_index != 3)
		{
			if (state->address < 0xA0)
			{
				/* Per-operator. */
				const cc_u8f operator_index_scrambled = (state->address >> 2) & 3;
				const cc_u8f operator_index = (operator_index_scrambled >> 1 | operator_index_scrambled << 1) & 3;

				switch (state->address / 0x10)
				{
					default:
						LogMessage("Unrecognised FM address latched (0x%02" CC_PRIXLEAST8 ")", state->address);
						break;

					case 0x30 / 0x10:
						/* Detune and multiplier. */
						FM_Channel_SetDetuneAndMultiplier(channel, operator_index, state->lfo.phase_modulation, (data >> 4) & 7, data & 0xF);
						break;

					case 0x40 / 0x10:
						/* Total level. */
						FM_Channel_SetTotalLevel(channel, operator_index, data & 0x7F);
						break;

					case 0x50 / 0x10:
						/* Key scale and attack rate. */
						FM_Channel_SetKeyScaleAndAttackRate(channel, operator_index, (data >> 6) & 3, data & 0x1F);
						break;

					case 0x60 / 0x10:
						/* Amplitude modulation on and decay rate. */
						FM_Channel_SetDecayRate(channel, operator_index, data & 0x1F);
						FM_Channel_SetAmplitudeModulationOn(channel, operator_index, (data & 0x80) != 0);
						break;

					case 0x70 / 0x10:
						/* Sustain rate. */
						FM_Channel_SetSustainRate(channel, operator_index, data & 0x1F);
						break;

					case 0x80 / 0x10:
						/* Sustain level and release rate. */
						FM_Channel_SetSustainLevelAndReleaseRate(channel, operator_index, (data >> 4) & 0xF, data & 0xF);
						break;

					case 0x90 / 0x10:
						/* SSG-EG. */
						FM_Channel_SetSSGEG(channel, operator_index, data);
						break;
				}
			}
			else
			{
				/* Per-channel. */
				switch (state->address / 4)
				{
					default:
						LogMessage("Unrecognised FM address latched (0x%02" CC_PRIXLEAST8 ")", state->address);
						break;

					case 0xA0 / 4:
					{
						/* Frequency low bits. */
						const cc_u16f frequency = data | (state->cached_upper_frequency_bits << 8);

						if (channel_index == 2) /* FM3 */
						{
							state->channel_3_metadata.frequencies[3] = frequency;

							if (state->channel_3_metadata.per_operator_frequencies_enabled)
							{
								FM_Channel_SetFrequency(&state->channels[2].state, 3, state->lfo.phase_modulation, frequency);
								break;
							}
						}

						FM_Channel_SetFrequencies(channel, state->lfo.phase_modulation, frequency);
						break;
					}

					case 0xA4 / 4:
						/* Frequency high bits. */
						/* http://gendev.spritesmind.net/forum/viewtopic.php?p=5621#p5621 */
						state->cached_upper_frequency_bits = data & 0x3F;
						break;

					case 0xA8 / 4:
						/* Frequency low bits (multi-frequency). */
						if (state->port == 0)
						{
							static const cc_u8l operator_mappings[3] = {2, 0, 1}; /* Oddly, the operators are switched-around here, just like the accumulation logic. */ /* TODO: Look into this some more. */
							const cc_u8f operator_index = operator_mappings[slot_index];
							const cc_u16f frequency = data | (state->cached_upper_frequency_bits_fm3_multi_frequency << 8);

							state->channel_3_metadata.frequencies[operator_index] = frequency;

							if (state->channel_3_metadata.per_operator_frequencies_enabled)
								FM_Channel_SetFrequency(&state->channels[2].state, operator_index, state->lfo.phase_modulation, frequency);
						}

						break;

					case 0xAC / 4:
						/* Frequency high bits. */
						/* http://gendev.spritesmind.net/forum/viewtopic.php?p=5621#p5621 */
						state->cached_upper_frequency_bits_fm3_multi_frequency = data & 0x3F;
						break;

					case 0xB0 / 4:
						FM_Channel_SetFeedbackAndAlgorithm(channel, (data >> 3) & 7, data & 7);
						break;

					case 0xB4 / 4:
						/* Panning, AMS, FMS. */
						channel_metadata->pan_left = (data & 0x80) != 0;
						channel_metadata->pan_right = (data & 0x40) != 0;

						FM_Channel_SetModulationSensitivity(channel, state->lfo.phase_modulation, (data >> 4) & 3, data & 7);
						break;
				}
			}
		}
	}
}

static cc_s16f GetFinalSample(const FM* const fm, cc_s16f sample, const cc_bool enabled)
{
	cc_s16f offset;

	/* Approximate the 'ladder effect' bug. */
	/* Modelled after Nuked OPN2's implementation. */
	/* https://github.com/nukeykt/Nuked-OPN2/blob/335747d78cb0abbc3b55b004e62dad9763140115/ym3438.c#L987 */
	if (fm->configuration.ladder_effect_disabled)
	{
		offset = 0;
	}
	else
	{
		if (sample < 0)
		{
			++sample;
			offset = -4;
		}
		else
		{
			offset = 4;
		}
	}

	if (!enabled)
		sample = 0;

	if (fm->state.dac_test)
	{
		/* Sample is output for all four slots. */
		sample *= 4;
		/* Since we don't multiplex output like a real YM2612 does, clamp here to avoid clipping. */
		sample = CC_CLAMP(-0xFF, 0xFF, sample);
	}
	else
	{
		sample += offset;
	}

	/* The FM sample is 9-bit, so convert it to 16-bit and then divide it so that it
	   can be mixed with the other five FM channels and the PSG without clipping. */
	return sample * (1 << (16 - 9)) / FM_VOLUME_DIVISOR;
}

static cc_s16f FM_ToNativeSigned(const cc_u16f value)
{
	return CC_SIGN_EXTEND_UINT(9 - 1, (cc_s16f)value);
}

void FM_OutputSamples(FM* const fm, cc_s16l* const sample_buffer, const cc_u32f total_frames)
{
	FM_State* const state = &fm->state;
	const cc_s16f dac_sample = FM_ToNativeSigned(state->dac_sample ^ 0x100);

	const cc_s16l* const sample_buffer_end = &sample_buffer[total_frames * 2];

	cc_s16l *sample_buffer_pointer;

	for (sample_buffer_pointer = sample_buffer; sample_buffer_pointer != sample_buffer_end; sample_buffer_pointer += 2)
	{
		cc_u8f channel_index, timer_index;

		if (FM_LFO_Advance(&state->lfo))
		{
			FM_ChannelMetadata *channel;

			for (channel = &state->channels[0]; channel < &state->channels[CC_COUNT_OF(state->channels)]; ++channel)
				FM_Channel_SetPhaseModulation(&channel->state, state->lfo.phase_modulation);
		}

		for (channel_index = 0; channel_index < CC_COUNT_OF(state->channels); ++channel_index)
		{
			FM_ChannelMetadata* const channel_metadata = &state->channels[channel_index];
			FM_Channel* const channel = &state->channels[channel_index].state;
			const cc_bool pan_left = channel_metadata->pan_left;
			const cc_bool pan_right = channel_metadata->pan_right;

			const cc_bool is_dac = (channel_index == 5 && state->dac_enabled) || state->dac_test;
			const cc_bool channel_disabled = is_dac ? fm->configuration.dac_channel_disabled : fm->configuration.fm_channels_disabled[channel_index];

			const cc_s16f fm_sample = FM_ToNativeSigned(FM_Channel_GetSample(channel, state->lfo.amplitude_modulation));
			const cc_s16f sample = is_dac ? dac_sample : fm_sample;

			if (!channel_disabled)
			{
				sample_buffer_pointer[0] += GetFinalSample(fm, sample, pan_left);
				sample_buffer_pointer[1] += GetFinalSample(fm, sample, pan_right);
			}
		}

		for (timer_index = 0; timer_index < CC_COUNT_OF(state->timers); ++timer_index)
		{
			FM_Timer* const timer = &state->timers[timer_index];

			if (--timer->counter == 0)
			{
				/* Set the 'timer expired' flag. */
				state->status |= timer->enabled ? 1 << timer_index : 0;

				/* Reload the timer's counter. */
				timer->counter = timer->value;

				/* Perform CSM key-on/key-off logic. */
				if (state->channel_3_metadata.csm_mode_enabled && timer_index == 0)
				{
					cc_u8f operator_index;

					for (operator_index = 0; operator_index < CC_COUNT_OF(state->channels[2].state.operators); ++operator_index)
					{
						FM_Channel_SetKeyOn(&state->channels[2].state, operator_index, cc_true);
						FM_Channel_SetKeyOn(&state->channels[2].state, operator_index, cc_false);
					}
				}
			}
		}
	}
}

cc_u8f FM_Update(FM* const fm, const cc_u32f cycles_to_do, void (* const fm_audio_to_be_generated)(const void *user_data, cc_u32f total_frames), const void* const user_data)
{
	FM_State* const state = &fm->state;
	const cc_u32f total_frames = (state->leftover_cycles + cycles_to_do) / FM_SAMPLE_RATE_DIVIDER;

	state->leftover_cycles = (state->leftover_cycles + cycles_to_do) % FM_SAMPLE_RATE_DIVIDER;

	if (total_frames != 0)
		fm_audio_to_be_generated(user_data, total_frames);

	/* Decrement the BUSY flag counter. */
	if (state->busy_flag_counter != 0)
	{
		state->busy_flag_counter -= CC_MIN(state->busy_flag_counter, cycles_to_do);

		/* Clear BUSY flag if the counter has elapsed. */
		if (state->busy_flag_counter == 0)
			state->status &= ~0x80;
	}

	return state->status;
}
