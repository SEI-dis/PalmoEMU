// SPDX-License-Identifier: AGPL-3.0-or-later
// Local file flow following ManicEMU RomPatcherView; no ROM is uploaded.
import {tr} from '../i18n/index.js';
import {applyROMPatch} from '../rom-patch.js';
import {guardUpdateTask} from '../update-activity.js';
export function showROMPatch({sheet,onClose,download,error}){
 sheet(tr('ROMパッチ'),tr('<p class="sheet-note">IPS・BPS・UPSに対応。元のROMとセーブは変更しません。</p><div class="settings-group"><label class="row"><span>元のROM</span><input id="patch-rom" type="file"></label><label class="row"><span>パッチ</span><input id="patch-file" type="file"></label></div><p class="sheet-note">各64 MiBまで。IPSにはROMの一致確認がありません。パッチ作者の指定するROMを選んでください。</p><button class="primary" id="apply-patch" disabled>適用して保存</button>'));
 const rom=document.querySelector('#patch-rom'),patch=document.querySelector('#patch-file'),button=document.querySelector('#apply-patch'),controller=new AbortController();let closed=false;
 onClose(()=>{closed=true;controller.abort();});rom.onchange=patch.onchange=()=>{button.disabled=!rom.files.length||!patch.files.length;};
 button.onclick=guardUpdateTask(async()=>{button.disabled=true;rom.disabled=patch.disabled=true;button.textContent=tr('適用中…');try{const file=rom.files[0],bytes=await applyROMPatch(file,patch.files[0],{signal:controller.signal});if(!closed){download(bytes,file.name.replace(/(\.[^.]+)?$/,'.patched$1'));button.textContent=tr('保存しました');}}catch(e){if(!closed)error(e);}finally{if(!closed){rom.disabled=patch.disabled=false;button.disabled=false;if(button.textContent===tr('適用中…'))button.textContent=tr('適用して保存');}}});
}
