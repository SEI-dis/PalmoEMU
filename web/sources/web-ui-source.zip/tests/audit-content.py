"""SPDX-License-Identifier: AGPL-3.0-or-later
Regression tests for the previously missed archive contents and stale source.
"""
from pathlib import Path
import importlib.util, io, json, tarfile, tempfile, unittest, zipfile, sys, shutil
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('audit', Path(__file__).resolve().parents[1] / 'scripts/audit-content.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)

def tar(name, content):
    out = io.BytesIO()
    with tarfile.open(fileobj=out, mode='w:gz') as t:
        info = tarfile.TarInfo(name); info.size = len(content)
        t.addfile(info, io.BytesIO(content))
    return out.getvalue()

def zip(name, content):
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w') as z: z.writestr(name, content)
    return out.getvalue()

class AuditTests(unittest.TestCase):
    def test_portable_release_inventory_order(self):
        # Windows Path ordering folds case; Linux Path ordering does not.
        # The same source tree must produce a pin that either OS can verify.
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            names = ['src/app.txt', 'assets/icon.svg', 'NOTICE.txt', 'src/App.js', 'LICENSE.txt']
            for name in names:
                file = root / name
                file.parent.mkdir(parents=True, exist_ok=True)
                file.write_bytes(b'original fixture')
            (root/'sources').mkdir()
            (root/'sources/web-ui-source.zip').write_bytes(zip('source.txt', b'original fixture'))
            (root/'offline-manifest.js').write_bytes(b'// original fixture')
            audit.run(root, record=True)
            inventory = json.loads((root/audit.PIN).read_text(encoding='utf8'))
            self.assertEqual([row['path'] for row in inventory['files']], sorted(names))
            audit.run(root)

    def test_rom_signature_with_an_innocent_extension(self):
        for offset, signature in [(0x104, 'ceed6666cc0d'), (4, '24ffae51699aa221'), (0xc0, '24ffae51699aa221')]:
            data = bytearray(1024); data[offset:offset+len(bytes.fromhex(signature))] = bytes.fromhex(signature)
            with self.assertRaisesRegex(ValueError, 'ROM signature'):
                audit.Scanner().inspect('image.png', bytes(data))

    def test_secret_and_private_data_in_archives(self):
        for name, data in [('settings/.env', b'private'), ('file.txt', b'gh' + b'p_' + b'x'*40), ('firmware.bios', b'private'), ('skin.deltaskin', b'private')]:
            with self.assertRaises(ValueError):
                audit.Scanner().inspect('source.zip', zip(name, data))

    def test_rom_hidden_in_tar_gzip_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'ROM/save'):
            audit.Scanner().inspect('source.tar.gz', tar('tests/fixture.gba', b'original test data'))

    def test_save_in_nested_zip_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'ROM/save'):
            audit.Scanner().inspect('outer.zip', zip('inner.zip', zip('save.sav', b'save data')))

    def test_every_tar_member_is_pinned(self):
        s = audit.Scanner(); s.inspect('source.tar.gz', tar('src/core.c', b'int main(){}'))
        self.assertEqual([x['path'] for x in s.rows], ['source.tar.gz', 'source.tar.gz!src/core.c'])

    def test_disguised_archive_and_unsafe_path(self):
        with self.assertRaisesRegex(ValueError, 'ROM/save'):
            audit.Scanner().inspect('opaque.dat', zip('private.srm', b'test'))
        with self.assertRaisesRegex(ValueError, 'Unsafe archive'):
            audit.Scanner().inspect('source.tar.gz', tar('../outside.c', b'x'))

    def test_unregistered_file_and_changed_file(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); (root/'app.js').write_text('original', encoding='utf8')
            audit.run(root, record=True)
            (root/'unknown.js').write_text('unreviewed', encoding='utf8')
            with self.assertRaisesRegex(ValueError, 'unregistered'): audit.run(root)
            (root/'unknown.js').unlink(); (root/'app.js').write_text('changed', encoding='utf8')
            with self.assertRaisesRegex(ValueError, 'changed'): audit.run(root)

class BundledSkinRights(unittest.TestCase):
    def test_unreviewed_artwork_and_missing_notices_are_rejected(self):
        root = Path(__file__).resolve().parents[1]
        spec = importlib.util.spec_from_file_location('bundled', root/'scripts/check-bundled-skins.py')
        bundled = importlib.util.module_from_spec(spec); spec.loader.exec_module(bundled)
        manifest = json.loads((root/'BUNDLED_SKINS.json').read_text())
        with tempfile.TemporaryDirectory() as d:
            copy = Path(d)
            for name in ['BUNDLED_SKINS.json', *manifest['files']]:
                dest = copy/name; dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(root/name, dest)
            bundled.verify(copy)
            extra = copy/'assets/skins/unreviewed.png'; extra.write_bytes(b'unapproved fixture')
            with self.assertRaisesRegex(AssertionError, 'Unreviewed'): bundled.verify(copy)
            extra.unlink()
            image = next(copy.glob('assets/skins/manic/gb/*.png')); original = image.read_bytes()
            image.write_bytes(b'changed fixture')
            with self.assertRaisesRegex(AssertionError, 'Changed reviewed'): bundled.verify(copy)
            image.write_bytes(original)
            (copy/manifest['licenseFile']).unlink()
            with self.assertRaises(FileNotFoundError): bundled.verify(copy)

if __name__ == '__main__': unittest.main()
